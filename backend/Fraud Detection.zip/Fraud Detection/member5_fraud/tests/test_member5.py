import os

os.environ["DATABASE_URL"] = "sqlite:///./test_member5.db"
os.environ["AUTH_MODE"] = "dev"

import pytest  # noqa: E402
from datetime import timedelta  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.database import Base, SessionLocal, engine, init_db  # noqa: E402
from app.main import app  # noqa: E402
from app.models_core import Customer, Transaction  # noqa: E402
from app.utils import utcnow  # noqa: E402

ANALYST = {"X-User-Id": "7", "X-User-Role": "ANALYST"}
MANAGER = {"X-User-Id": "3", "X-User-Role": "BUSINESS_MANAGER"}


@pytest.fixture()
def client():
    Base.metadata.drop_all(bind=engine)
    init_db()
    with TestClient(app) as c:
        yield c
    Base.metadata.drop_all(bind=engine)


def _tx(db, cid, amount, minutes_ago, device="d1", ip="1.1.1.1", loc="Cairo", **kw):
    t = Transaction(customer_id=cid, amount=amount, device_id=device, ip_address=ip, location=loc,
                    created_at=utcnow() - timedelta(minutes=minutes_ago), **kw)
    db.add(t)
    db.flush()
    return t


def test_rapid_transactions_create_alert(client):
    db = SessionLocal()
    db.add(Customer(id=1, name="A"))
    db.flush()
    last = None
    for m in range(6):
        last = _tx(db, 1, 10, 5 - m * 0.5)
    db.commit()
    r = client.post(f"/api/fraud/evaluate/{last.id}", headers=ANALYST)
    assert r.status_code == 200
    body = r.json()
    assert "rapid_transactions" in [p["name"] for p in body["patterns"]]
    assert body["alert_created"] is True


def test_device_sharing_and_suspicious_devices(client):
    db = SessionLocal()
    for i in (1, 2):
        db.add(Customer(id=i, name=f"C{i}"))
    db.flush()
    _tx(db, 1, 50, 30, device="shared")
    t = _tx(db, 2, 50, 5, device="shared")
    db.commit()
    r = client.post(f"/api/fraud/evaluate/{t.id}?dry_run=true", headers=ANALYST).json()
    assert "device_sharing" in [p["name"] for p in r["patterns"]]
    assert r["alert_id"] is None  # dry run persists nothing
    devs = client.get("/api/fraud/suspicious-devices", headers=ANALYST).json()
    assert devs[0]["device_id"] == "shared" and devs[0]["customer_count"] == 2


def _seed_alert(client):
    db = SessionLocal()
    db.add(Customer(id=1, name="A"))
    db.flush()
    for i in range(6):
        _tx(db, 1, 50, 60 * 24 * (10 - i), risk_score=10, risk_level="LOW")
    t = _tx(db, 1, 900, 1, device="new", loc="Dubai", risk_score=85, risk_level="HIGH", decision="BLOCK")
    db.commit()
    r = client.post(f"/api/fraud/evaluate/{t.id}", headers=ANALYST).json()
    assert r["alert_created"]
    return r["alert_id"], t.id


def test_review_flow_updates_status_feedback_and_profile(client):
    alert_id, _ = _seed_alert(client)
    r = client.post(f"/api/alerts/{alert_id}/review", json={"status": "INVESTIGATING"}, headers=ANALYST)
    assert r.status_code == 200 and r.json()["status"] == "INVESTIGATING"
    invs = client.get("/api/investigations", headers=ANALYST).json()
    assert len(invs) == 1 and invs[0]["status"] == "IN_PROGRESS"

    r = client.post(f"/api/alerts/{alert_id}/review",
                    json={"status": "CONFIRMED_FRAUD", "notes": "card stolen"}, headers=ANALYST)
    assert r.json()["status"] == "CONFIRMED_FRAUD"
    assert client.get("/api/investigations", headers=ANALYST).json()[0]["status"] == "CLOSED"

    prof = client.get("/api/customers/1/risk-profile", headers=ANALYST).json()
    assert prof["confirmed_fraud_count"] == 1 and prof["fraud_reports"] == 1
    hist = client.get(f"/api/alerts/{alert_id}/history", headers=ANALYST).json()
    assert [h["new_status"] for h in hist] == ["NEW", "INVESTIGATING", "CONFIRMED_FRAUD"]

    # terminal states cannot go back
    bad = client.post(f"/api/alerts/{alert_id}/review", json={"status": "INVESTIGATING"}, headers=ANALYST)
    assert bad.status_code == 409


def test_false_positive_lowers_customer_score(client):
    alert_id, _ = _seed_alert(client)
    before = client.get("/api/customers/1/risk-profile", headers=ANALYST).json()["risk_score"]
    client.post(f"/api/alerts/{alert_id}/review", json={"status": "FALSE_POSITIVE"}, headers=ANALYST)
    after = client.get("/api/customers/1/risk-profile", headers=ANALYST).json()
    assert after["false_positive_count"] == 1 and after["risk_score"] < before


def test_permissions(client):
    alert_id, _ = _seed_alert(client)
    assert client.post(f"/api/alerts/{alert_id}/review", json={"status": "RESOLVED"}, headers=MANAGER).status_code == 403
    assert client.get("/api/alerts", headers=MANAGER).status_code == 200
    assert client.get("/api/alerts").status_code == 401
    assert client.post(f"/api/alerts/{alert_id}/assign", json={"assignee_id": 7}, headers=MANAGER).status_code == 200
    notes = client.get("/api/notifications", headers=ANALYST).json()
    assert any("assigned to you" in n["message"] or "New fraud alert" in n["message"] for n in notes)


def test_investigation_detail_has_everything(client):
    alert_id, _ = _seed_alert(client)
    inv = client.post("/api/investigations", json={"alert_id": alert_id}, headers=ANALYST).json()
    client.post(f"/api/investigations/{inv['id']}/notes", json={"note": "called customer"}, headers=ANALYST)
    d = client.get(f"/api/investigations/{inv['id']}", headers=ANALYST).json()
    for key in ("customer", "risk_profile", "transaction_history", "related_transactions", "devices",
                "ips", "locations", "risk_factors", "risk_explanation", "related_alerts", "notes", "history"):
        assert key in d
    assert d["notes"][0]["note"] == "called customer"
    assert d["risk_explanation"]["reasons"]
