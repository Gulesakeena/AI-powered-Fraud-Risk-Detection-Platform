@echo off
REM Starts the API using the project's own Python (installs packages first if missing).
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe call setup.bat
.venv\Scripts\python.exe -c "import sqlalchemy, fastapi, uvicorn, jwt" 2>nul || (
  echo Packages missing - installing...
  .venv\Scripts\python.exe -m pip install -r requirements.txt
)
if not exist fraud_member5.db .venv\Scripts\python.exe scripts\seed_demo.py
echo Open http://127.0.0.1:8000/docs
.venv\Scripts\python.exe -m uvicorn app.main:app --reload
pause
