@echo off
cd /d "%~dp0"
echo --- Python used by the project ---
if exist .venv\Scripts\python.exe (.venv\Scripts\python.exe --version & .venv\Scripts\python.exe -c "import sqlalchemy,fastapi,uvicorn,jwt;print('All packages OK, sqlalchemy',sqlalchemy.__version__)") else (echo .venv not found - run setup.bat)
echo --- Default python on PATH ---
python --version
pause
