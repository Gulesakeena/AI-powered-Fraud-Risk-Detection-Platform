@echo off
REM One-time setup: creates .venv and installs all packages into it.
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py) || (set PY=python)
if not exist .venv\Scripts\python.exe (
  echo Creating virtual environment...
  %PY% -m venv .venv || (echo Could not create venv. Is Python installed? & pause & exit /b 1)
)
echo Installing packages...
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt || (echo Install failed. & pause & exit /b 1)
echo.
echo Setup complete. Now run:  run.bat
pause
