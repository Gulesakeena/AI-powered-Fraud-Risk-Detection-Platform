"""Creates demo customers/transactions, then runs the Member 5 pipeline on them."""
import os
import sys
from datetime import timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import SessionLocal, init_db  # noqa: E402
from app.models_core import Customer, Transaction  # noqa: E402
from app.services.pipeline import process_scored_transaction  # noqa: E402
from app.utils import utcnow  # noqa: E402

init_db()
db = SessionLocal()
if db.query(Customer).count():
    print("Database already has data - delete fraud_member5.db to re-seed.")
    sys.exit(0)

now = utcnow()
for i, name in enumerate(["Ahmed", "Sara", "Omar", "Laila", "Youssef", "Nour"], start=1):
    db.add(Customer(id=i, name=name, email=f"{name.lower()}@example.com"))
db.flush()


def tx(cid, amount, minutes_ago, device, ip, loc, **kw):
    t = Transaction(customer_id=cid, amount=amount, device_id=device, ip_address=ip,
                    location=loc, created_at=now - timedelta(minutes=minutes_ago), **kw)
    db.add(t)
    db.flush()
    return t


# Customer 1: normal history, then a suspicious big purchase from a new device/location
for d in range(8):
    tx(1, 60 + d * 5, 60 * 24 * (10 - d), "dev-ahmed", "10.0.0.1", "Cairo", risk_score=10, risk_level="LOW", decision="APPROVE")
t1 = tx(1, 950, 2, "dev-new-9", "41.2.3.4", "Dubai", ml_score=88, risk_score=87, risk_level="HIGH", decision="BLOCK")

# Customer 2: burst of rapid transactions
for m in range(6):
    t2 = tx(2, 40, 6 - m, "dev-sara", "10.0.0.2", "Giza", risk_score=55, risk_level="MEDIUM", decision="REVIEW")

# Customers 3,4,5 share one device and one IP
t3 = tx(3, 120, 30, "dev-shared", "10.9.9.9", "Alexandria", risk_score=60, risk_level="MEDIUM", decision="REVIEW")
t4 = tx(4, 130, 20, "dev-shared", "10.9.9.9", "Alexandria", risk_score=62, risk_level="MEDIUM", decision="REVIEW")
t5 = tx(5, 140, 10, "dev-shared", "10.9.9.9", "Alexandria", risk_score=65, risk_level="MEDIUM", decision="REVIEW")
tx(6, 25, 5, "dev-nour", "10.0.0.6", "Cairo", risk_score=5, risk_level="LOW", decision="APPROVE")
db.commit()

for t in (t1, t2, t3, t4, t5):
    r = process_scored_transaction(db, t.id)
    print(f"tx {t.id}: patterns={[p['name'] for p in r['patterns']]} alert_id={r['alert_id']}")
db.commit()
print("Seed complete.")
