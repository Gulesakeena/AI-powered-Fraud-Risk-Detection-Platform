"""Create a test JWT for AUTH_MODE=jwt:  python scripts/make_token.py 1 ANALYST"""
import datetime
import os
import sys

import jwt

uid, role = (sys.argv[1], sys.argv[2]) if len(sys.argv) > 2 else ("1", "ANALYST")
secret = os.getenv("JWT_SECRET", "change-me")
exp = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=8)
print(jwt.encode({"sub": uid, "role": role.upper(), "exp": exp}, secret, algorithm="HS256"))
