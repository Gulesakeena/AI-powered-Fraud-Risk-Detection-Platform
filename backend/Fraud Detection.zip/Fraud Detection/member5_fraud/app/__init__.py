try:
    import fastapi, sqlalchemy, jwt  # noqa: F401
except ModuleNotFoundError as e:  # pragma: no cover
    raise SystemExit(
        f"\nMissing package: {e.name}\n"
        "Fix: run  setup.bat  (or:  python -m pip install -r requirements.txt)\n"
        "then start with  run.bat  (or:  python -m uvicorn app.main:app --reload)\n"
        "Make sure the terminal shows (.venv) and VS Code uses the .venv interpreter.\n"
    )
