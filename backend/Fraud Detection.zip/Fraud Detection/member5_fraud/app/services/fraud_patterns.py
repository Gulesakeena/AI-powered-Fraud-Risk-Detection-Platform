"""
Fraud pattern detection. Every hit is computed from real rows in the database
and carries its evidence, so alerts/explanations are never fabricated.
"""
import statistics
from dataclasses import asdict, dataclass, field
from datetime import timedelta
from typing import Optional

from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import config as cfg
from ..models import CustomerRiskProfile
from ..models_core import Transaction


@dataclass
class PatternHit:
    name: str
    points: int
    description: str
    evidence: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def _prior(db: Session, tx: Transaction):
    return (
        db.query(Transaction)
        .filter(
            Transaction.customer_id == tx.customer_id,
            Transaction.id != tx.id,
            Transaction.created_at <= tx.created_at,
        )
        .all()
    )


def _customers_sharing(db: Session, tx: Transaction, column: str) -> set:
    value = getattr(tx, column)
    if not value:
        return set()
    since = tx.created_at - timedelta(days=cfg.SHARING_LOOKBACK_DAYS)
    rows = (
        db.query(Transaction.customer_id)
        .filter(
            getattr(Transaction, column) == value,
            Transaction.created_at >= since,
            Transaction.created_at <= tx.created_at,
        )
        .distinct()
        .all()
    )
    return {r[0] for r in rows} | {tx.customer_id}


def detect_patterns(db: Session, tx: Transaction, ml_score: Optional[float] = None) -> list:
    hits: list = []
    prior = _prior(db, tx)

    # 1. Rapid transactions
    since = tx.created_at - timedelta(minutes=cfg.RAPID_WINDOW_MINUTES)
    count = (
        db.query(func.count(Transaction.id))
        .filter(
            Transaction.customer_id == tx.customer_id,
            Transaction.created_at >= since,
            Transaction.created_at <= tx.created_at,
        )
        .scalar()
    )
    if count >= cfg.RAPID_TX_COUNT:
        hits.append(PatternHit(
            "rapid_transactions",
            min(40, 20 + 5 * (count - cfg.RAPID_TX_COUNT)),
            f"{count} transactions within {cfg.RAPID_WINDOW_MINUTES} minutes",
            {"count": count, "window_minutes": cfg.RAPID_WINDOW_MINUTES},
        ))

    # 2. Device sharing
    dev_custs = _customers_sharing(db, tx, "device_id")
    if len(dev_custs) >= cfg.DEVICE_SHARING_MIN_CUSTOMERS:
        hits.append(PatternHit(
            "device_sharing",
            min(35, 15 * (len(dev_custs) - 1)),
            f"Device {tx.device_id} used by {len(dev_custs)} different customers",
            {"device_id": tx.device_id, "customer_ids": sorted(dev_custs)},
        ))

    # 3. IP sharing
    ip_custs = _customers_sharing(db, tx, "ip_address")
    if len(ip_custs) >= cfg.IP_SHARING_MIN_CUSTOMERS:
        hits.append(PatternHit(
            "ip_sharing",
            min(35, 10 * (len(ip_custs) - 1)),
            f"IP {tx.ip_address} used by {len(ip_custs)} different customers",
            {"ip_address": tx.ip_address, "customer_ids": sorted(ip_custs)},
        ))

    # 4. Location anomaly
    known_locations = {p.location for p in prior if p.location}
    new_location = bool(tx.location) and len(prior) >= 3 and tx.location not in known_locations
    if new_location:
        hits.append(PatternHit(
            "location_anomaly", 25,
            f"New location '{tx.location}' never used in {len(prior)} previous transactions",
            {"location": tx.location, "known_locations": sorted(known_locations)},
        ))

    # 5. Transaction amount anomaly (statistical, vs. customer's own history)
    amounts = [p.amount for p in prior if p.amount is not None]
    if len(amounts) >= cfg.MIN_HISTORY and tx.amount is not None:
        mean = statistics.fmean(amounts)
        std = statistics.pstdev(amounts)
        z = (tx.amount - mean) / std if std > 0 else 0.0
        if z >= cfg.AMOUNT_ZSCORE or (mean > 0 and tx.amount >= cfg.AMOUNT_MULTIPLIER * mean):
            hits.append(PatternHit(
                "amount_anomaly", 30,
                f"Amount {tx.amount:.2f} is far above this customer's average {mean:.2f}",
                {"amount": tx.amount, "mean": round(mean, 2), "std": round(std, 2),
                 "z_score": round(z, 2), "history_size": len(amounts)},
            ))

    # 6. Account behaviour change: new device AND new location on an established account
    known_devices = {p.device_id for p in prior if p.device_id}
    new_device = bool(tx.device_id) and len(prior) >= 3 and tx.device_id not in known_devices
    if new_device and new_location:
        hits.append(PatternHit(
            "account_behavior_change", 25,
            "New device and new location used together on an established account",
            {"device_id": tx.device_id, "location": tx.location},
        ))

    # 7. ML anomaly signal from Member 3 (if available)
    ml = ml_score if ml_score is not None else tx.ml_score
    if ml is not None and ml >= cfg.ML_ANOMALY_THRESHOLD:
        hits.append(PatternHit(
            "ml_anomaly", 20, f"ML anomaly score is high ({ml:.0f}/100)", {"ml_score": ml},
        ))

    # 8. Suspicious relationship: shares device/IP with a customer with confirmed fraud
    others = (dev_custs | ip_custs) - {tx.customer_id}
    if others:
        flagged = [
            r[0] for r in db.query(CustomerRiskProfile.customer_id)
            .filter(CustomerRiskProfile.customer_id.in_(others),
                    CustomerRiskProfile.confirmed_fraud_count > 0)
        ]
        if flagged:
            hits.append(PatternHit(
                "suspicious_relationship", 40,
                f"Shares a device/IP with customer(s) with confirmed fraud: {sorted(flagged)}",
                {"confirmed_fraud_customer_ids": sorted(flagged)},
            ))

    return hits


def pattern_score(hits: list) -> int:
    return min(100, sum(h.points for h in hits))


def suspicious_shared(db: Session, column: str, min_customers: int) -> list:
    """Devices / IPs used by several customers (column = 'device_id' | 'ip_address')."""
    col = getattr(Transaction, column)
    rows = (
        db.query(col, func.count(func.distinct(Transaction.customer_id)), func.count(Transaction.id))
        .filter(col.isnot(None))
        .group_by(col)
        .having(func.count(func.distinct(Transaction.customer_id)) >= min_customers)
        .order_by(func.count(func.distinct(Transaction.customer_id)).desc())
        .all()
    )
    out = []
    for value, n_customers, n_tx in rows:
        ids = sorted(r[0] for r in db.query(Transaction.customer_id).filter(col == value).distinct())
        fraud_ids = [
            r[0] for r in db.query(CustomerRiskProfile.customer_id)
            .filter(CustomerRiskProfile.customer_id.in_(ids),
                    CustomerRiskProfile.confirmed_fraud_count > 0)
        ]
        out.append({column: value, "customer_count": n_customers, "transaction_count": n_tx,
                    "customer_ids": ids, "confirmed_fraud_customer_ids": sorted(fraud_ids)})
    return out
