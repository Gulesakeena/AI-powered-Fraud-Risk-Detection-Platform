from typing import Optional

from sqlalchemy.orm import Session

from ..models import Alert, AlertFeedback, AlertHistory, Investigation, Notification
from ..models_core import Transaction
from ..utils import utcnow
from . import customer_risk, investigations

FINAL = ("CONFIRMED_FRAUD", "FALSE_POSITIVE", "RESOLVED")
TRANSITIONS = {
    "NEW": {"INVESTIGATING", "CONFIRMED_FRAUD", "FALSE_POSITIVE", "RESOLVED"},
    "INVESTIGATING": {"CONFIRMED_FRAUD", "FALSE_POSITIVE", "RESOLVED"},
    "CONFIRMED_FRAUD": {"RESOLVED"},
    "FALSE_POSITIVE": {"RESOLVED"},
    "RESOLVED": set(),
}


class InvalidTransition(ValueError):
    pass


def _history(db, alert_id, action, old=None, new=None, actor=None, note=None):
    db.add(AlertHistory(alert_id=alert_id, action=action, old_status=old, new_status=new,
                        actor_id=actor, note=note))


def notify(db: Session, message: str, alert_id: int, user_id: int = None, role: str = None):
    db.add(Notification(user_id=user_id, role=role, alert_id=alert_id, message=message))


def create_alert(db: Session, tx: Transaction, severity: str, reason: str, hits: list,
                 risk_score=None, risk_level=None, decision=None,
                 assigned_to: Optional[int] = None) -> Alert:
    alert = Alert(
        transaction_id=tx.id, customer_id=tx.customer_id, severity=severity, reason=reason,
        patterns=[h["name"] for h in hits], evidence=hits, risk_score=risk_score,
        risk_level=risk_level, decision=decision, status="NEW", assigned_to=assigned_to,
    )
    db.add(alert)
    db.flush()
    _history(db, alert.id, "CREATED", None, "NEW", None, reason)
    msg = f"[{severity}] New fraud alert #{alert.id} for customer {tx.customer_id}: {reason}"
    if assigned_to:
        notify(db, msg, alert.id, user_id=assigned_to)
    else:
        notify(db, msg, alert.id, role="ANALYST")
        if severity in ("HIGH", "CRITICAL"):
            notify(db, msg, alert.id, role="ADMIN")
    return alert


def assign_alert(db: Session, alert: Alert, assignee_id: int, actor_id: int) -> Alert:
    alert.assigned_to = assignee_id
    _history(db, alert.id, "ASSIGNED", alert.status, alert.status, actor_id, f"assigned to user {assignee_id}")
    notify(db, f"Alert #{alert.id} ({alert.severity}) was assigned to you", alert.id, user_id=assignee_id)
    db.flush()
    return alert


def review_alert(db: Session, alert: Alert, new_status: str, actor_id: int, notes: str = None) -> Alert:
    old = alert.status
    if new_status not in TRANSITIONS.get(old, set()):
        raise InvalidTransition(f"Cannot change alert from {old} to {new_status}")

    alert.status = new_status
    alert.reviewed_by = actor_id
    alert.reviewed_at = utcnow()
    if notes:
        alert.review_notes = notes
    _history(db, alert.id, "STATUS_CHANGE", old, new_status, actor_id, notes)

    # Feedback for Member 3 (only the first verdict; RESOLVED after a verdict adds nothing new)
    if new_status in FINAL and not (new_status == "RESOLVED" and old in FINAL):
        db.add(AlertFeedback(
            alert_id=alert.id, transaction_id=alert.transaction_id, customer_id=alert.customer_id,
            label=new_status,
            is_fraud=True if new_status == "CONFIRMED_FRAUD" else False if new_status == "FALSE_POSITIVE" else None,
            risk_score=alert.risk_score, patterns=alert.patterns, reviewer_id=actor_id, notes=notes,
        ))

    # Investigation sync
    inv = db.query(Investigation).filter(Investigation.alert_id == alert.id).first()
    if new_status == "INVESTIGATING":
        if inv is None:
            inv = investigations.create_investigation(db, alert_id=alert.id, actor_id=actor_id,
                                                      assigned_to=alert.assigned_to)
        investigations.update_investigation(db, inv, actor_id, status="IN_PROGRESS")
    elif new_status in FINAL and inv is not None and inv.status != "CLOSED":
        investigations.update_investigation(db, inv, actor_id, status="CLOSED", outcome=new_status)

    db.flush()
    customer_risk.refresh_profile(db, alert.customer_id)
    return alert
