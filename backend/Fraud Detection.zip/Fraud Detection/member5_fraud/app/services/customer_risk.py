"""
Customer Risk Profile. Recomputed from real data on every relevant event.

Score formula (clamped 0-100):
  base  = average final risk_score of the customer's last 20 scored transactions
  + min(30, 10 * confirmed_fraud)      confirmed fraud history
  + min(15,  3 * open_alerts)          alerts still NEW / INVESTIGATING
  - min(20,  5 * false_positives)      cleared alerts lower the score
Level: 0-30 LOW, 31-70 MEDIUM, 71-100 HIGH.
"""
from sqlalchemy.orm import Session

from ..models import Alert, AlertFeedback, CustomerRiskProfile
from ..models_core import Transaction
from ..utils import level_from_score, utcnow


def refresh_profile(db: Session, customer_id: int) -> CustomerRiskProfile:
    txs = (
        db.query(Transaction)
        .filter(Transaction.customer_id == customer_id)
        .order_by(Transaction.created_at.desc())
        .all()
    )
    alerts = db.query(Alert).filter(Alert.customer_id == customer_id).all()
    alert_tx = {a.transaction_id for a in alerts}
    cleared_tx = {a.transaction_id for a in alerts if a.status == "FALSE_POSITIVE"}
    suspicious = {
        t.id for t in txs if t.risk_level in ("MEDIUM", "HIGH") or t.id in alert_tx
    } - cleared_tx

    # RESOLVED alerts keep their fraud verdict through AlertFeedback:
    confirmed = (
        db.query(AlertFeedback)
        .filter(AlertFeedback.customer_id == customer_id, AlertFeedback.label == "CONFIRMED_FRAUD")
        .count()
    )
    false_pos = (
        db.query(AlertFeedback)
        .filter(AlertFeedback.customer_id == customer_id, AlertFeedback.label == "FALSE_POSITIVE")
        .count()
    )
    open_alerts = sum(1 for a in alerts if a.status in ("NEW", "INVESTIGATING"))

    scored = [t.risk_score for t in txs[:20] if t.risk_score is not None]
    base = sum(scored) / len(scored) if scored else 0.0
    score = base + min(30, 10 * confirmed) + min(15, 3 * open_alerts) - min(20, 5 * false_pos)
    score = round(max(0.0, min(100.0, score)), 1)

    profile = db.get(CustomerRiskProfile, customer_id)
    if profile is None:
        profile = CustomerRiskProfile(customer_id=customer_id)
        db.add(profile)
    profile.risk_score = score
    profile.risk_level = level_from_score(score)
    profile.total_transactions = len(txs)
    profile.suspicious_transactions = len(suspicious)
    profile.devices_used = sorted({t.device_id for t in txs if t.device_id})
    profile.locations_used = sorted({t.location for t in txs if t.location})
    profile.fraud_reports = len(alerts)
    profile.confirmed_fraud_count = confirmed
    profile.false_positive_count = false_pos
    profile.last_updated = utcnow()
    db.flush()
    return profile
