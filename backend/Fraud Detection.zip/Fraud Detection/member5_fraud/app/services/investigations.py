from typing import Optional

from sqlalchemy.orm import Session

from .. import integration
from ..models import (Alert, CustomerRiskProfile, Investigation, InvestigationHistory,
                      InvestigationNote)
from ..models_core import Customer, Transaction
from ..utils import to_dict, utcnow


def _log(db: Session, inv_id: int, action: str, detail: str = None, actor_id: int = None):
    db.add(InvestigationHistory(investigation_id=inv_id, action=action, detail=detail, actor_id=actor_id))


def create_investigation(db: Session, alert_id: Optional[int] = None, customer_id: Optional[int] = None,
                         title: Optional[str] = None, assigned_to: Optional[int] = None,
                         actor_id: Optional[int] = None) -> Investigation:
    alert = db.get(Alert, alert_id) if alert_id else None
    if alert_id and alert is None:
        raise LookupError("Alert not found")
    if alert:
        existing = db.query(Investigation).filter(Investigation.alert_id == alert.id).first()
        if existing:
            return existing
        customer_id = alert.customer_id
    if not customer_id or db.get(Customer, customer_id) is None:
        raise LookupError("Customer not found")
    inv = Investigation(
        alert_id=alert.id if alert else None,
        customer_id=customer_id,
        title=title or (f"Investigation of alert #{alert.id}" if alert else f"Investigation of customer #{customer_id}"),
        status="OPEN", assigned_to=assigned_to or (alert.assigned_to if alert else None),
        created_by=actor_id,
    )
    db.add(inv)
    db.flush()
    _log(db, inv.id, "CREATED", inv.title, actor_id)
    return inv


def add_note(db: Session, inv: Investigation, note: str, author_id: int):
    n = InvestigationNote(investigation_id=inv.id, author_id=author_id, note=note)
    db.add(n)
    inv.updated_at = utcnow()
    _log(db, inv.id, "NOTE_ADDED", note[:200], author_id)
    db.flush()
    return n


def update_investigation(db: Session, inv: Investigation, actor_id: int, status: str = None,
                         assigned_to: int = None, outcome: str = None):
    if status and status != inv.status:
        _log(db, inv.id, "STATUS_CHANGE", f"{inv.status} -> {status}", actor_id)
        inv.status = status
    if assigned_to is not None and assigned_to != inv.assigned_to:
        _log(db, inv.id, "ASSIGNED", f"assigned to user {assigned_to}", actor_id)
        inv.assigned_to = assigned_to
    if outcome:
        inv.outcome = outcome
    inv.updated_at = utcnow()
    db.flush()


def get_detail(db: Session, inv: Investigation) -> dict:
    cid = inv.customer_id
    customer = db.get(Customer, cid)
    profile = db.get(CustomerRiskProfile, cid)
    txs = (db.query(Transaction).filter(Transaction.customer_id == cid)
           .order_by(Transaction.created_at.desc()).limit(50).all())
    devices = sorted({t.device_id for t in txs if t.device_id})
    ips = sorted({t.ip_address for t in txs if t.ip_address})
    locations = sorted({t.location for t in txs if t.location})

    related = []
    if devices or ips:
        q = db.query(Transaction).filter(Transaction.customer_id != cid)
        rows = q.filter((Transaction.device_id.in_(devices or [""])) |
                        (Transaction.ip_address.in_(ips or [""]))) \
                .order_by(Transaction.created_at.desc()).limit(50).all()
        for t in rows:
            via = []
            if t.device_id in devices:
                via.append(f"device {t.device_id}")
            if t.ip_address in ips:
                via.append(f"ip {t.ip_address}")
            related.append({**to_dict(t), "linked_via": via})

    alerts = db.query(Alert).filter(Alert.customer_id == cid).order_by(Alert.created_at.desc()).all()
    main_alert = db.get(Alert, inv.alert_id) if inv.alert_id else (alerts[0] if alerts else None)

    risk_factors, explanation = [], None
    if main_alert:
        risk_factors = main_alert.evidence or []
        explanation = integration.get_risk_explanation(db, main_alert.transaction_id)
        if explanation is None:
            explanation = {
                "source": "alert_evidence",
                "transaction_id": main_alert.transaction_id,
                "risk_score": main_alert.risk_score,
                "risk_level": main_alert.risk_level,
                "decision": main_alert.decision,
                "reasons": [h["description"] for h in risk_factors] or [main_alert.reason],
            }
    notes = db.query(InvestigationNote).filter(InvestigationNote.investigation_id == inv.id) \
        .order_by(InvestigationNote.created_at).all()
    history = db.query(InvestigationHistory).filter(InvestigationHistory.investigation_id == inv.id) \
        .order_by(InvestigationHistory.created_at, InvestigationHistory.id).all()
    return {
        "investigation": to_dict(inv),
        "customer": to_dict(customer) if customer else None,
        "risk_profile": to_dict(profile) if profile else None,
        "transaction_history": [to_dict(t) for t in txs],
        "related_transactions": related,
        "devices": devices, "ips": ips, "locations": locations,
        "risk_factors": risk_factors,
        "risk_explanation": explanation,
        "related_alerts": [to_dict(a) for a in alerts],
        "notes": [to_dict(n) for n in notes],
        "history": [to_dict(h) for h in history],
    }
