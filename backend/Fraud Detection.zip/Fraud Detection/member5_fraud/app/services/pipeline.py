"""
ENTRY POINT FOR MEMBER 4's Real-Time Risk Pipeline.

After the Risk Decision Engine stores the final score/decision for a
transaction, call:

    from app.services.pipeline import process_scored_transaction
    result = process_scored_transaction(db, tx.id, risk_score=87, risk_level="HIGH",
                                        decision="BLOCK", ml_score=91)
    db.commit()

Arguments left as None are read from the transaction row. The function:
  detect patterns -> create alert if required -> update customer risk profile.
"""
from sqlalchemy.orm import Session

from .. import config as cfg
from ..models import Alert
from ..models_core import Transaction
from ..utils import level_from_score
from . import alerts, customer_risk, fraud_patterns


def _severity(level: str, score: float, hits: list, pscore: int) -> str:
    sev = {"HIGH": "HIGH", "MEDIUM": "MEDIUM"}.get(level, "LOW")
    if pscore >= cfg.ALERT_PATTERN_SCORE_THRESHOLD and sev == "LOW":
        sev = "MEDIUM"
    if score >= 90 or any(h.name == "suspicious_relationship" for h in hits):
        sev = "CRITICAL"
    return sev


def process_scored_transaction(db: Session, transaction_id: int, risk_score=None, risk_level=None,
                               decision=None, ml_score=None, persist: bool = True) -> dict:
    tx = db.get(Transaction, transaction_id)
    if tx is None:
        raise LookupError("Transaction not found")
    risk_score = risk_score if risk_score is not None else tx.risk_score
    decision = decision or tx.decision
    hits = fraud_patterns.detect_patterns(db, tx, ml_score)
    pscore = fraud_patterns.pattern_score(hits)
    effective = risk_score if risk_score is not None else float(pscore)
    level = risk_level or tx.risk_level or level_from_score(effective)

    should_alert = (decision in ("REVIEW", "BLOCK") or level == "HIGH"
                    or pscore >= cfg.ALERT_PATTERN_SCORE_THRESHOLD)
    result = {
        "transaction_id": tx.id, "customer_id": tx.customer_id,
        "patterns": [h.to_dict() for h in hits], "pattern_score": pscore,
        "risk_score": effective, "risk_level": level, "decision": decision,
        "alert_required": should_alert, "alert_created": False, "alert_id": None,
    }
    if not persist:
        return result

    existing = db.query(Alert).filter(Alert.transaction_id == tx.id).first()
    if existing:
        result["alert_id"] = existing.id
    elif should_alert:
        reason = "; ".join(h.description for h in hits) or \
            f"Transaction {decision or level} by Risk Decision Engine (score {effective:.0f})"
        alert = alerts.create_alert(
            db, tx, _severity(level, effective, hits, pscore), reason,
            [h.to_dict() for h in hits], effective, level, decision)
        result.update(alert_created=True, alert_id=alert.id)
        db.flush()
    customer_risk.refresh_profile(db, tx.customer_id)
    return result
