"""
STAND-IN tables owned by other members (Member 2: customers/transactions).

When you merge into the real project, DELETE the classes below and instead
re-export the real ones, e.g.:

    from app.models.transaction import Transaction, Customer   # Member 2's models

Member 5 code only needs these columns:
  Customer:    id, name, email
  Transaction: id, customer_id, amount, device_id, ip_address, location,
               created_at, ml_score, risk_score, risk_level, decision
"""
from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String

from .database import Base
from .utils import utcnow


class Customer(Base):
    __tablename__ = "customers"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    email = Column(String(200))
    created_at = Column(DateTime, default=utcnow)


class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), index=True, nullable=False)
    amount = Column(Float, nullable=False)
    currency = Column(String(8), default="USD")
    device_id = Column(String(120), index=True)
    ip_address = Column(String(64), index=True)
    location = Column(String(120))
    created_at = Column(DateTime, default=utcnow, index=True)
    # Filled by Member 3 / Member 4:
    ml_score = Column(Float)        # 0-100 ML anomaly score
    risk_score = Column(Float)      # 0-100 final score
    risk_level = Column(String(10))  # LOW / MEDIUM / HIGH
    decision = Column(String(10))   # APPROVE / REVIEW / BLOCK
