"""All tunable settings for Member 5. Override with environment variables."""
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./fraud_member5.db")

# AUTH_MODE: "dev" -> trust X-User-Id / X-User-Role headers (local testing only)
#            "jwt" -> require "Authorization: Bearer <token>" (claims: sub, role)
AUTH_MODE = os.getenv("AUTH_MODE", "dev")
JWT_SECRET = os.getenv("JWT_SECRET", "change-me")   # must equal Member 1's secret
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

# Fraud pattern thresholds
RAPID_WINDOW_MINUTES = int(os.getenv("RAPID_WINDOW_MINUTES", "10"))
RAPID_TX_COUNT = int(os.getenv("RAPID_TX_COUNT", "5"))
DEVICE_SHARING_MIN_CUSTOMERS = int(os.getenv("DEVICE_SHARING_MIN_CUSTOMERS", "2"))
IP_SHARING_MIN_CUSTOMERS = int(os.getenv("IP_SHARING_MIN_CUSTOMERS", "3"))
SHARING_LOOKBACK_DAYS = int(os.getenv("SHARING_LOOKBACK_DAYS", "30"))
AMOUNT_ZSCORE = float(os.getenv("AMOUNT_ZSCORE", "3.0"))
AMOUNT_MULTIPLIER = float(os.getenv("AMOUNT_MULTIPLIER", "5.0"))
MIN_HISTORY = int(os.getenv("MIN_HISTORY", "5"))
ML_ANOMALY_THRESHOLD = float(os.getenv("ML_ANOMALY_THRESHOLD", "70"))
ALERT_PATTERN_SCORE_THRESHOLD = int(os.getenv("ALERT_PATTERN_SCORE_THRESHOLD", "25"))
