"""
Authorization for Member 5 endpoints.

Thin adapter. When Member 1's auth is ready, replace the body of
get_current_user() with Member 1's dependency (it only needs to return an
object with .id and .role). Keep PERMISSIONS aligned with the project matrix.
"""
from dataclasses import dataclass
from typing import Optional

import jwt
from fastapi import Depends, Header, HTTPException

from . import config

ROLES = ("ADMIN", "BUSINESS_MANAGER", "ANALYST")

PERMISSIONS = {
    "alerts:view": ROLES,
    "alerts:create": ("ADMIN", "ANALYST"),
    "alerts:review": ("ADMIN", "ANALYST"),
    "alerts:assign": ("ADMIN", "BUSINESS_MANAGER"),
    "investigations:view": ROLES,
    "investigations:manage": ("ADMIN", "ANALYST"),
    "customers:view": ROLES,
    "customers:refresh": ("ADMIN", "ANALYST"),
    "fraud:view": ROLES,
    "fraud:evaluate": ("ADMIN", "ANALYST"),
    "notifications:view": ROLES,
}


@dataclass
class CurrentUser:
    id: int
    role: str


def get_current_user(
    authorization: Optional[str] = Header(None),
    x_user_id: Optional[str] = Header(None),
    x_user_role: Optional[str] = Header(None),
) -> CurrentUser:
    if config.AUTH_MODE == "dev":
        if not x_user_id or not x_user_role:
            raise HTTPException(401, "Dev mode: send X-User-Id and X-User-Role headers")
        uid, role = x_user_id, x_user_role
    else:
        if not authorization or not authorization.lower().startswith("bearer "):
            raise HTTPException(401, "Missing bearer token")
        try:
            claims = jwt.decode(authorization[7:], config.JWT_SECRET, algorithms=[config.JWT_ALGORITHM])
        except jwt.ExpiredSignatureError:
            raise HTTPException(401, "Token expired")
        except jwt.PyJWTError:
            raise HTTPException(401, "Invalid token")
        uid, role = claims.get("sub"), claims.get("role")
    try:
        uid = int(uid)
    except (TypeError, ValueError):
        raise HTTPException(401, "Invalid user id")
    role = (role or "").upper()
    if role not in ROLES:
        raise HTTPException(403, "Unknown role")
    return CurrentUser(id=uid, role=role)


def require(permission: str):
    allowed = PERMISSIONS[permission]

    def dep(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if user.role not in allowed:
            raise HTTPException(403, f"Role {user.role} lacks permission {permission}")
        return user

    return dep
