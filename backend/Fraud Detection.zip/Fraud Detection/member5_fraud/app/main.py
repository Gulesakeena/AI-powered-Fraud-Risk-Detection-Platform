from contextlib import asynccontextmanager

from fastapi import FastAPI

from .database import init_db
from .routers import alerts, customers, fraud, investigations, notifications


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(title="Fraud Platform - Member 5 (Detection, Alerts, Investigation, Customer Risk)",
              lifespan=lifespan)
for r in (alerts, investigations, customers, fraud, notifications):
    app.include_router(r.router)


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}
