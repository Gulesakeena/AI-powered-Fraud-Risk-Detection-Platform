"""Member 5 tables: alerts, investigations, customer risk profile, feedback."""
from sqlalchemy import JSON, Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text

from . import models_core  # noqa: F401  (ensures FK targets are registered)
from .database import Base
from .utils import utcnow

ALERT_STATUSES = ("NEW", "INVESTIGATING", "CONFIRMED_FRAUD", "FALSE_POSITIVE", "RESOLVED")


class Alert(Base):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True)
    transaction_id = Column(Integer, ForeignKey("transactions.id"), index=True, nullable=False)
    customer_id = Column(Integer, ForeignKey("customers.id"), index=True, nullable=False)
    severity = Column(String(10), nullable=False)        # LOW / MEDIUM / HIGH / CRITICAL
    reason = Column(Text, nullable=False)
    patterns = Column(JSON, default=list)                # names of detected patterns
    evidence = Column(JSON, default=list)                # full pattern hits (real data)
    risk_score = Column(Float)
    risk_level = Column(String(10))
    decision = Column(String(10))
    status = Column(String(20), nullable=False, default="NEW", index=True)
    assigned_to = Column(Integer, index=True)
    reviewed_by = Column(Integer)
    reviewed_at = Column(DateTime)
    review_notes = Column(Text)
    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)


class AlertHistory(Base):
    __tablename__ = "alert_history"
    id = Column(Integer, primary_key=True)
    alert_id = Column(Integer, ForeignKey("alerts.id"), index=True, nullable=False)
    action = Column(String(30), nullable=False)          # CREATED / STATUS_CHANGE / ASSIGNED
    old_status = Column(String(20))
    new_status = Column(String(20))
    actor_id = Column(Integer)
    note = Column(Text)
    created_at = Column(DateTime, default=utcnow)


class Notification(Base):
    """Addressed to a specific user_id OR to everyone holding `role`."""
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, index=True)
    role = Column(String(30), index=True)
    alert_id = Column(Integer, ForeignKey("alerts.id"))
    message = Column(Text, nullable=False)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utcnow)


class AlertFeedback(Base):
    """Labelled outcomes for Member 3's model-improvement pipeline."""
    __tablename__ = "alert_feedback"
    id = Column(Integer, primary_key=True)
    alert_id = Column(Integer, ForeignKey("alerts.id"), index=True)
    transaction_id = Column(Integer, ForeignKey("transactions.id"), index=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), index=True)
    label = Column(String(20), nullable=False)           # CONFIRMED_FRAUD / FALSE_POSITIVE / RESOLVED
    is_fraud = Column(Boolean)                           # True / False / None
    risk_score = Column(Float)
    patterns = Column(JSON, default=list)
    reviewer_id = Column(Integer)
    notes = Column(Text)
    created_at = Column(DateTime, default=utcnow)


class Investigation(Base):
    __tablename__ = "investigations"
    id = Column(Integer, primary_key=True)
    alert_id = Column(Integer, ForeignKey("alerts.id"), index=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), index=True, nullable=False)
    title = Column(String(200), nullable=False)
    status = Column(String(20), nullable=False, default="OPEN")   # OPEN / IN_PROGRESS / CLOSED
    outcome = Column(String(20))                                   # CONFIRMED_FRAUD / FALSE_POSITIVE / RESOLVED
    assigned_to = Column(Integer)
    created_by = Column(Integer)
    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)


class InvestigationNote(Base):
    __tablename__ = "investigation_notes"
    id = Column(Integer, primary_key=True)
    investigation_id = Column(Integer, ForeignKey("investigations.id"), index=True, nullable=False)
    author_id = Column(Integer)
    note = Column(Text, nullable=False)
    created_at = Column(DateTime, default=utcnow)


class InvestigationHistory(Base):
    __tablename__ = "investigation_history"
    id = Column(Integer, primary_key=True)
    investigation_id = Column(Integer, ForeignKey("investigations.id"), index=True, nullable=False)
    action = Column(String(30), nullable=False)
    detail = Column(Text)
    actor_id = Column(Integer)
    created_at = Column(DateTime, default=utcnow)


class CustomerRiskProfile(Base):
    __tablename__ = "customer_risk_profiles"
    customer_id = Column(Integer, ForeignKey("customers.id"), primary_key=True)
    risk_score = Column(Float, default=0)
    risk_level = Column(String(10), default="LOW")
    total_transactions = Column(Integer, default=0)
    suspicious_transactions = Column(Integer, default=0)
    devices_used = Column(JSON, default=list)
    locations_used = Column(JSON, default=list)
    fraud_reports = Column(Integer, default=0)            # total alerts raised
    confirmed_fraud_count = Column(Integer, default=0)
    false_positive_count = Column(Integer, default=0)
    last_updated = Column(DateTime, default=utcnow, onupdate=utcnow)
