"""
Hooks to other members' code. Everything here has a safe default so Member 5
works standalone; replace the bodies when the other parts exist.
"""
from typing import Optional

from sqlalchemy.orm import Session


def get_risk_explanation(db: Session, transaction_id: int) -> Optional[dict]:
    """
    MEMBER 4 HOOK: return the output of GET /api/risk/{transaction_id}/explanation
    (e.g. {"risk_score": 87, "risk_level": "HIGH", "reasons": [...]}).
    Return None to fall back to the evidence Member 5 stored on the alert.
    """
    return None
