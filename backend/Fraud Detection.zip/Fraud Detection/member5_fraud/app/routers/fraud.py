from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import config as cfg
from ..database import get_db
from ..security import CurrentUser, require
from ..services import fraud_patterns
from ..services.pipeline import process_scored_transaction

router = APIRouter(prefix="/api/fraud", tags=["Fraud Detection"])


class EvaluateIn(BaseModel):
    risk_score: Optional[float] = None
    risk_level: Optional[str] = None
    decision: Optional[str] = None
    ml_score: Optional[float] = None


@router.post("/evaluate/{transaction_id}")
def evaluate(transaction_id: int, body: Optional[EvaluateIn] = None, dry_run: bool = False,
             db: Session = Depends(get_db), user: CurrentUser = Depends(require("fraud:evaluate"))):
    """Run pattern detection + alerting + profile update. dry_run=true changes nothing."""
    body = body or EvaluateIn()
    try:
        result = process_scored_transaction(db, transaction_id, body.risk_score, body.risk_level,
                                            body.decision, body.ml_score, persist=not dry_run)
    except LookupError as e:
        raise HTTPException(404, str(e))
    db.commit()
    return result


@router.get("/suspicious-devices")
def suspicious_devices(min_customers: int = cfg.DEVICE_SHARING_MIN_CUSTOMERS,
                       db: Session = Depends(get_db), user: CurrentUser = Depends(require("fraud:view"))):
    return fraud_patterns.suspicious_shared(db, "device_id", max(2, min_customers))


@router.get("/suspicious-ips")
def suspicious_ips(min_customers: int = cfg.IP_SHARING_MIN_CUSTOMERS,
                   db: Session = Depends(get_db), user: CurrentUser = Depends(require("fraud:view"))):
    return fraud_patterns.suspicious_shared(db, "ip_address", max(2, min_customers))
