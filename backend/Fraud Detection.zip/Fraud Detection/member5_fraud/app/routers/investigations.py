from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Investigation
from ..security import CurrentUser, require
from ..services import investigations as svc
from ..utils import to_dict

router = APIRouter(prefix="/api/investigations", tags=["Investigations"])
STATUSES = ("OPEN", "IN_PROGRESS", "CLOSED")
OUTCOMES = ("CONFIRMED_FRAUD", "FALSE_POSITIVE", "RESOLVED")


class InvestigationIn(BaseModel):
    alert_id: Optional[int] = None
    customer_id: Optional[int] = None
    title: Optional[str] = None
    assigned_to: Optional[int] = None


class InvestigationPatch(BaseModel):
    status: Optional[str] = None
    assigned_to: Optional[int] = None
    outcome: Optional[str] = None


class NoteIn(BaseModel):
    note: str


def _get(db, inv_id) -> Investigation:
    inv = db.get(Investigation, inv_id)
    if inv is None:
        raise HTTPException(404, "Investigation not found")
    return inv


@router.post("", status_code=201)
def create(body: InvestigationIn, db: Session = Depends(get_db),
           user: CurrentUser = Depends(require("investigations:manage"))):
    if not body.alert_id and not body.customer_id:
        raise HTTPException(422, "Provide alert_id or customer_id")
    try:
        inv = svc.create_investigation(db, body.alert_id, body.customer_id, body.title,
                                       body.assigned_to, user.id)
    except LookupError as e:
        raise HTTPException(404, str(e))
    db.commit()
    return to_dict(inv)


@router.get("")
def list_investigations(status: Optional[str] = None, customer_id: Optional[int] = None,
                        db: Session = Depends(get_db),
                        user: CurrentUser = Depends(require("investigations:view"))):
    q = db.query(Investigation)
    if status:
        q = q.filter(Investigation.status == status.upper())
    if customer_id:
        q = q.filter(Investigation.customer_id == customer_id)
    return [to_dict(i) for i in q.order_by(Investigation.created_at.desc()).all()]


@router.get("/{inv_id}")
def detail(inv_id: int, db: Session = Depends(get_db),
           user: CurrentUser = Depends(require("investigations:view"))):
    return svc.get_detail(db, _get(db, inv_id))


@router.patch("/{inv_id}")
def patch(inv_id: int, body: InvestigationPatch, db: Session = Depends(get_db),
          user: CurrentUser = Depends(require("investigations:manage"))):
    inv = _get(db, inv_id)
    if body.status and body.status.upper() not in STATUSES:
        raise HTTPException(422, f"status must be one of {STATUSES}")
    if body.outcome and body.outcome.upper() not in OUTCOMES:
        raise HTTPException(422, f"outcome must be one of {OUTCOMES}")
    svc.update_investigation(db, inv, user.id, body.status and body.status.upper(),
                             body.assigned_to, body.outcome and body.outcome.upper())
    db.commit()
    return to_dict(inv)


@router.post("/{inv_id}/notes", status_code=201)
def add_note(inv_id: int, body: NoteIn, db: Session = Depends(get_db),
             user: CurrentUser = Depends(require("investigations:manage"))):
    inv = _get(db, inv_id)
    if not body.note.strip():
        raise HTTPException(422, "note cannot be empty")
    n = svc.add_note(db, inv, body.note.strip(), user.id)
    db.commit()
    return to_dict(n)
