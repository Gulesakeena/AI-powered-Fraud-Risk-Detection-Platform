from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Notification
from ..security import CurrentUser, require
from ..utils import to_dict

router = APIRouter(prefix="/api/notifications", tags=["Notifications"])


@router.get("")
def my_notifications(unread_only: bool = False, db: Session = Depends(get_db),
                     user: CurrentUser = Depends(require("notifications:view"))):
    q = db.query(Notification).filter(or_(Notification.user_id == user.id, Notification.role == user.role))
    if unread_only:
        q = q.filter(Notification.is_read.is_(False))
    return [to_dict(n) for n in q.order_by(Notification.created_at.desc()).limit(100).all()]


@router.post("/{notification_id}/read")
def mark_read(notification_id: int, db: Session = Depends(get_db),
              user: CurrentUser = Depends(require("notifications:view"))):
    n = db.get(Notification, notification_id)
    if n is None or (n.user_id not in (None, user.id) and n.role != user.role):
        raise HTTPException(404, "Notification not found")
    n.is_read = True
    db.commit()
    return to_dict(n)
