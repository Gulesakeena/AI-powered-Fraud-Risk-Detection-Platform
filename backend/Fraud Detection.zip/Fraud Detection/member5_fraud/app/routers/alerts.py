from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import ALERT_STATUSES, Alert, AlertHistory
from ..models_core import Transaction
from ..security import CurrentUser, require
from ..services import alerts as svc
from ..services import customer_risk
from ..utils import to_dict

router = APIRouter(prefix="/api/alerts", tags=["Alerts"])


class ReviewIn(BaseModel):
    status: str
    notes: Optional[str] = None


class AssignIn(BaseModel):
    assignee_id: int


class AlertCreateIn(BaseModel):
    transaction_id: int
    severity: str = "MEDIUM"
    reason: str


def _get(db, alert_id) -> Alert:
    a = db.get(Alert, alert_id)
    if a is None:
        raise HTTPException(404, "Alert not found")
    return a


@router.get("")
def list_alerts(status: Optional[str] = None, severity: Optional[str] = None,
                customer_id: Optional[int] = None, assigned_to: Optional[int] = None,
                page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=200),
                db: Session = Depends(get_db), user: CurrentUser = Depends(require("alerts:view"))):
    q = db.query(Alert)
    if status:
        q = q.filter(Alert.status == status.upper())
    if severity:
        q = q.filter(Alert.severity == severity.upper())
    if customer_id:
        q = q.filter(Alert.customer_id == customer_id)
    if assigned_to:
        q = q.filter(Alert.assigned_to == assigned_to)
    total = q.count()
    rows = q.order_by(Alert.created_at.desc()).offset((page - 1) * page_size).limit(page_size).all()
    return {"items": [to_dict(a) for a in rows], "total": total, "page": page, "page_size": page_size}


@router.get("/stats")
def alert_stats(db: Session = Depends(get_db), user: CurrentUser = Depends(require("alerts:view"))):
    """Counts per status/severity (usable by Member 2's dashboard)."""
    by_status = dict(db.query(Alert.status, func.count(Alert.id)).group_by(Alert.status).all())
    by_sev = dict(db.query(Alert.severity, func.count(Alert.id)).group_by(Alert.severity).all())
    return {"total": sum(by_status.values()),
            "by_status": {s: by_status.get(s, 0) for s in ALERT_STATUSES},
            "by_severity": by_sev}


@router.post("", status_code=201)
def create_manual_alert(body: AlertCreateIn, db: Session = Depends(get_db),
                        user: CurrentUser = Depends(require("alerts:create"))):
    tx = db.get(Transaction, body.transaction_id)
    if tx is None:
        raise HTTPException(404, "Transaction not found")
    if body.severity.upper() not in ("LOW", "MEDIUM", "HIGH", "CRITICAL"):
        raise HTTPException(422, "severity must be LOW, MEDIUM, HIGH or CRITICAL")
    a = svc.create_alert(db, tx, body.severity.upper(), body.reason, [], tx.risk_score,
                         tx.risk_level, tx.decision)
    customer_risk.refresh_profile(db, tx.customer_id)
    db.commit()
    return to_dict(a)


@router.get("/{alert_id}")
def get_alert(alert_id: int, db: Session = Depends(get_db),
              user: CurrentUser = Depends(require("alerts:view"))):
    a = _get(db, alert_id)
    hist = db.query(AlertHistory).filter(AlertHistory.alert_id == alert_id) \
        .order_by(AlertHistory.created_at, AlertHistory.id).all()
    return {**to_dict(a), "history": [to_dict(h) for h in hist]}


@router.get("/{alert_id}/history")
def alert_history(alert_id: int, db: Session = Depends(get_db),
                  user: CurrentUser = Depends(require("alerts:view"))):
    _get(db, alert_id)
    hist = db.query(AlertHistory).filter(AlertHistory.alert_id == alert_id) \
        .order_by(AlertHistory.created_at, AlertHistory.id).all()
    return [to_dict(h) for h in hist]


@router.post("/{alert_id}/review")
def review(alert_id: int, body: ReviewIn, db: Session = Depends(get_db),
           user: CurrentUser = Depends(require("alerts:review"))):
    a = _get(db, alert_id)
    status = body.status.upper()
    if status not in ALERT_STATUSES or status == "NEW":
        raise HTTPException(422, f"status must be one of {[s for s in ALERT_STATUSES if s != 'NEW']}")
    try:
        svc.review_alert(db, a, status, user.id, body.notes)
    except svc.InvalidTransition as e:
        db.rollback()
        raise HTTPException(409, str(e))
    db.commit()
    return to_dict(a)


@router.post("/{alert_id}/assign")
def assign(alert_id: int, body: AssignIn, db: Session = Depends(get_db),
           user: CurrentUser = Depends(require("alerts:assign"))):
    a = _get(db, alert_id)
    svc.assign_alert(db, a, body.assignee_id, user.id)
    db.commit()
    return to_dict(a)
