from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import CustomerRiskProfile
from ..models_core import Customer
from ..security import CurrentUser, require
from ..services import customer_risk
from ..utils import to_dict

router = APIRouter(prefix="/api/customers", tags=["Customer Risk"])


@router.get("/risk-profiles")
def list_profiles(level: Optional[str] = None, limit: int = 50, db: Session = Depends(get_db),
                  user: CurrentUser = Depends(require("customers:view"))):
    q = db.query(CustomerRiskProfile)
    if level:
        q = q.filter(CustomerRiskProfile.risk_level == level.upper())
    rows = q.order_by(CustomerRiskProfile.risk_score.desc()).limit(min(limit, 500)).all()
    return [to_dict(p) for p in rows]


@router.get("/{customer_id}/risk-profile")
def get_profile(customer_id: int, db: Session = Depends(get_db),
                user: CurrentUser = Depends(require("customers:view"))):
    if db.get(Customer, customer_id) is None:
        raise HTTPException(404, "Customer not found")
    p = db.get(CustomerRiskProfile, customer_id)
    if p is None:
        p = customer_risk.refresh_profile(db, customer_id)
        db.commit()
    return to_dict(p)


@router.post("/{customer_id}/risk-profile/refresh")
def refresh(customer_id: int, db: Session = Depends(get_db),
            user: CurrentUser = Depends(require("customers:refresh"))):
    if db.get(Customer, customer_id) is None:
        raise HTTPException(404, "Customer not found")
    p = customer_risk.refresh_profile(db, customer_id)
    db.commit()
    return to_dict(p)
