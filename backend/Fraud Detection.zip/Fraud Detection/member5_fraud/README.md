# Member 5 — Fraud Detection, Alerts, Investigation & Customer Risk

FastAPI + SQLAlchemy module. Runs standalone (SQLite, stand-in customer/transaction tables)
and plugs into the main project with two small edits (see "Integrating").

## 0. Fastest way (Windows)
Double-click **`setup.bat`** once (creates `.venv` and installs everything), then **`run.bat`**
(seeds demo data and starts the server). `test.bat` runs the tests.
If you ever see `ModuleNotFoundError`, just run `setup.bat` again.

## 1. Run it manually (Windows + VS Code, PowerShell terminal)

```powershell
cd member5_fraud
python -m venv .venv
.venv\Scripts\Activate.ps1          # if blocked: Set-ExecutionPolicy -Scope Process Bypass
pip install -r requirements.txt

python scripts/seed_demo.py         # demo customers, transactions, alerts (optional)
uvicorn app.main:app --reload       # http://127.0.0.1:8000
```

Open **http://127.0.0.1:8000/docs** (Swagger UI). In the default `AUTH_MODE=dev`, fill the
headers on each request: `X-User-Id` = `7`, `X-User-Role` = `ANALYST`
(roles: `ADMIN`, `BUSINESS_MANAGER`, `ANALYST`).

## 2. Try the main flow (Swagger or curl.exe)

1. `GET /api/alerts` — list alerts (seed creates 5).
2. `GET /api/alerts/1` — alert with reason, evidence, history.
3. `POST /api/alerts/1/review` body `{"status":"INVESTIGATING","notes":"checking"}`
   -> status updates, an Investigation is auto-created, history is written.
4. `GET /api/investigations/1` — customer, risk profile, transaction history, related
   transactions, devices/IPs/locations, risk factors, explanation, related alerts, notes.
5. `POST /api/investigations/1/notes` body `{"note":"called the customer"}`
6. `POST /api/alerts/1/review` body `{"status":"CONFIRMED_FRAUD"}`
   -> feedback row saved (for Member 3), investigation closed, customer risk profile updated.
7. `GET /api/customers/1/risk-profile` — score/level, counts, devices, locations, fraud history.

```powershell
curl.exe -X POST http://127.0.0.1:8000/api/alerts/1/review `
  -H "X-User-Id: 7" -H "X-User-Role: ANALYST" -H "Content-Type: application/json" `
  -d '{\"status\":\"CONFIRMED_FRAUD\",\"notes\":\"confirmed with bank\"}'
```

## 3. Run the tests
```powershell
python -m pytest -q
```

## 4. Endpoints

| Method | Path | Roles |
|---|---|---|
| GET | /api/alerts (filters: status, severity, customer_id, assigned_to, page) | all |
| GET | /api/alerts/stats · /api/alerts/{id} · /api/alerts/{id}/history | all |
| POST | /api/alerts (manual) | ADMIN, ANALYST |
| **POST** | **/api/alerts/{id}/review** `{status, notes}` | ADMIN, ANALYST |
| POST | /api/alerts/{id}/assign `{assignee_id}` | ADMIN, BUSINESS_MANAGER |
| POST/GET | /api/investigations · GET /api/investigations/{id} | create: ADMIN, ANALYST |
| PATCH | /api/investigations/{id} `{status, assigned_to, outcome}` | ADMIN, ANALYST |
| POST | /api/investigations/{id}/notes | ADMIN, ANALYST |
| GET | /api/customers/{id}/risk-profile · /api/customers/risk-profiles?level=HIGH | all |
| POST | /api/customers/{id}/risk-profile/refresh | ADMIN, ANALYST |
| POST | /api/fraud/evaluate/{transaction_id}?dry_run=false | ADMIN, ANALYST |
| GET | /api/fraud/suspicious-devices · /api/fraud/suspicious-ips | all |
| GET/POST | /api/notifications · /api/notifications/{id}/read | all |

Alert statuses: `NEW, INVESTIGATING, CONFIRMED_FRAUD, FALSE_POSITIVE, RESOLVED`.
Allowed moves: NEW -> any; INVESTIGATING -> any final; CONFIRMED_FRAUD/FALSE_POSITIVE -> RESOLVED.
Anything else returns 409.

## 5. What gets detected (all from real DB rows; thresholds in `app/config.py`)
rapid transactions · device sharing · IP sharing · location anomaly · amount anomaly (vs the
customer's own history) · account behaviour change (new device + new location) · ML anomaly
(Member 3's score) · suspicious relationship (shares device/IP with a confirmed-fraud customer).
An alert is created when the decision is REVIEW/BLOCK, the level is HIGH, or patterns score >= 25.
Severity follows the risk level; CRITICAL if score >= 90 or linked to confirmed fraud.

Customer risk score = avg of last 20 transaction risk scores + 10/confirmed fraud (max 30)
+ 3/open alert (max 15) − 5/false positive (max 20), clamped 0–100; 0–30 LOW, 31–70 MEDIUM, 71–100 HIGH.

## 6. Integrating with the other members

1. **Member 2 (models):** in `app/models_core.py` delete the stand-in `Customer`/`Transaction`
   classes and import the real ones (needs: customer_id, amount, device_id, ip_address,
   location, created_at, ml_score, risk_score, risk_level, decision — rename columns if theirs differ).
2. **Member 1 (auth):** in `app/security.py`, make `get_current_user()` use their JWT dependency
   (or set `AUTH_MODE=jwt` and the same `JWT_SECRET`; token claims `sub` and `role`).
   Align `PERMISSIONS` with the project matrix. Use their `Base`/DB session in `app/database.py`.
3. **Member 4 (pipeline):** after the final score/decision is stored, call
   ```python
   from app.services.pipeline import process_scored_transaction
   process_scored_transaction(db, tx.id, risk_score=87, risk_level="HIGH", decision="BLOCK", ml_score=91)
   db.commit()
   ```
   To show their explanation inside investigations, fill `get_risk_explanation()` in `app/integration.py`.
4. **Member 3:** labelled outcomes are in table `alert_feedback` (`is_fraud`, `label`, `patterns`, `risk_score`).
5. **Member 2 dashboard:** `GET /api/alerts/stats` gives counts per status/severity;
   confirmed fraud and false positives are the `CONFIRMED_FRAUD` / `FALSE_POSITIVE` counts.
6. Mount the routers in the main app: `app.include_router(alerts.router)` etc. (see `app/main.py`).
